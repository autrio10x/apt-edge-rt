#!/usr/bin/env bash
# Write the vault drop-in for this board. Called from the package postinst.
# A row in boards.tab that requires a TPM fails when the device node is absent.
# Any other machine gets the file vault.
set -euo pipefail

ROOT="${KEYSTONE_HOST_ROOT:-/}"
ROOT="${ROOT%/}"
[[ -n "$ROOT" ]] || ROOT="/"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TAB="${KEYSTONE_BOARDS_TAB:-${SCRIPT_DIR}/boards.tab}"
DROPIN="${KEYSTONE_VAULT_DROPIN:-/usr/lib/systemd/system/keystone.service.d/10-keystore.conf}"

if [[ ! -f "$TAB" ]]; then
  echo "missing boards table: ${TAB}" >&2
  exit 2
fi

lower() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]'
}

read_text() {
  if [[ -f "$1" ]]; then
    tr -d '\000' <"$1" | tr '\n' ' '
  fi
}

product="$(lower "$(read_text "${ROOT}/sys/class/dmi/id/product_name")")"
model="$(lower "$(read_text "${ROOT}/proc/device-tree/model")")"

tpm=0
if [[ -e "${ROOT}/dev/tpmrm0" || -e "${ROOT}/dev/tpm0" ]]; then
  tpm=1
fi

vault=file
while read -r kind pattern want require _; do
  [[ -z "${kind:-}" ]] && continue
  [[ "$kind" == \#* ]] && continue
  pat="$(lower "$pattern")"
  case "$kind" in
    dmi) haystack="$product" ;;
    dt) haystack="$model" ;;
    *)
      echo "bad boards.tab kind: ${kind}" >&2
      exit 2
      ;;
  esac
  if [[ "$haystack" == *"$pat"* ]]; then
    if [[ "${require:-}" == tpm && "$tpm" -ne 1 ]]; then
      echo "host vault: ${pattern} requires a TPM device" >&2
      exit 1
    fi
    vault="$want"
    break
  fi
done <"$TAB"

mkdir -p "$(dirname "$DROPIN")"
cat >"$DROPIN" <<EOF
[Service]
Environment=KEYSTONE_KEYSTORE_BACKEND=${vault}
EOF
echo "host vault: ${vault}"
